
# Cosmic Company

#### Greetings fellow loyal employees! I've come to inform you of the recent gas giant implosion in the next galaxy over. Zeta Reticuli has sent debris flying out into space, causing never before seen circumstances to occur in and around the planets we orbit!
 
#### Due to these unforeseeable circumstances, the company needs you and your co-workers to investigate these new conditions and report back on them as soon as possible!




## Modpack Contents

<details>
<summary>New Moons</summary>

    74 Olympus

    91 Arelion

    692 Seichi

    Harloth

    Celest

    Aquatis

    Hyve

    615Noctis

    69_Kanie

</details>




- Tons of new interiors
- An abundance of new scraps
- New functional items including:

     >- Polaroid Camera
     >- Elite Flashlight
     >- Wheelbarrow
     >- Emergancy Dice
     >- Uno Reverse Card

    
- New monsters
- QOL Tweaks
- New Weather


## This description will have more soon! it's a work in progress and there is lots more content in the modpack that isn't yet listed here!

       